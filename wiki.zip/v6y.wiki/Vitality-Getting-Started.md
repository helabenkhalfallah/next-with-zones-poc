This page provides a comprehensive guide to setting up, installing, and working on the **Vitality** project. Vitality is a centralized telemetry system designed to integrate multiple tools, enabling better debugging, performance tracking, and user experience improvements. Follow the instructions below to get started.

---

## 🔧 Main Technologies Used

### 🖥️ Frontend
- [Node.js](https://nodejs.org/)
- [NX](https://nx.dev/)
- [React](https://reactjs.org/)
- [Ant Design (Antd)](https://ant.design/)
- [Next.js](https://nextjs.org/)
- [TanStack Query](https://tanstack.com/query/latest)

### 🏢 Frontend Back Office (BO)
- [Node.js](https://nodejs.org/)
- [PNPM](https://pnpm.io/)
- [NX](https://nx.dev/)
- [React](https://reactjs.org/)
- [Ant Design (Antd)](https://ant.design/)
- [Refine](https://refine.dev/)
- [Next.js](https://nextjs.org/)
- [TanStack Query](https://tanstack.com/query/latest)

### ⚙ Backend
- [Node.js](https://nodejs.org/)
- [PNPM](https://pnpm.io/)
- [NX](https://nx.dev/)
- [PostgreSQL (PSQL)](https://www.postgresql.org/)
- [pgAdmin 4](https://www.pgadmin.org/)
- [Nodemon](https://www.npmjs.com/package/nodemon)
- [Express.js](https://expressjs.com/)
- [GraphQL](https://graphql.org/) (via [Apollo](https://www.apollographql.com/))

---

## 📥 Installation Guide

### Prerequisites

1. Install **PostgreSQL** for your [OS](https://postgresapp.com/downloads.html).
2. Install **pgAdmin 4** for your [OS](https://www.pgadmin.org/download/).
3. Install **Node.js** using nvm (minimum version **22.11.0**).
4. Install **pnpm** using:
   ```bash
   npm i -g pnpm
   ```
   Minimum version: **9.15.4**.

---

### 🗄️ Database Configuration

#### 1. Create a Role in PostgreSQL

- Open your terminal and type `psql`.
- Use `\du` to list existing roles.
- If `your_name` does not exist, create a role using the following command:

  ```sql
  CREATE ROLE "your_name" LOGIN PASSWORD 'your_password';
  ```

  **Example:**

  ```sql
  CREATE ROLE "john_dupon" LOGIN PASSWORD 'awesome_password';
  ```

  **🔴 Note:** The `postgres` role should exist by default as a superuser.

#### 2. Set Up a New Connection in pgAdmin 4

- Open **pgAdmin 4** and create a new server connection.
- Use the following details:
  - **Name:** `v6y_database`
  - **Hostname:** `localhost`

#### ⚠ Common Errors

```
bash: psql: command not found
```

Fix by adding PostgreSQL to your system's PATH:

```
export PATH=/path/to/PostgreSQL/bin:$PATH
```

---

### 🚀 Project Installation

#### 1. Clone the Repository

```bash
git clone https://github.com/ekino/v6y.git
```

#### 2. Navigate to the Project Directory

```bash
cd v6y
```

#### 3. Install Dependencies with PNPM

```bash
pnpm install
```

This installs dependencies for all monorepo modules.

#### 4. Configure Environment Variables

- In these directories: `v6y`, `v6y-libs/core-logic`, `front`, `front-bo`, `bff`, and `bfb-*`, create an `.env` **file** according to the `env-template` file content.
- Refer to [GitLab Personal Access Tokens](https://docs.gitlab.com/ee/user/profile/personal_access_tokens.html) and [GitHub Personal Access Tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens) for generating tokens.

- Initialize the database by running the following command from the root folder:
  ```bash
  pnpm run init-db
  ```

---

### 📡 Running the Application

#### 🖥️ Frontend Only

The **Frontend** is responsible for displaying the user interface of the application, while the **Backend for Frontend (BFF)** acts as an intermediary layer between the frontend and backend systems. It handles data aggregation and communication with the backend services, ensuring that the frontend receives the required data in an optimized format.

To start these components:

1. Start the **Backend for Frontend**:
   ```bash
   cd v6y-apps/bff
   pnpm start:dev
   ```

2. Start the **Frontend**:
   ```bash
   cd v6y-apps/front
   pnpm start:dev
   ```

**🔵 GraphQL Playground:**
Access the playground at `http://localhost:4001/v6y/graphql` for testing queries and mutations.

#### 🏢 Frontend Back Office (BO) Only

The **Frontend Back Office (BO)** is designed for administrative tasks, providing tools for managing application configurations, user accounts, and other backend settings. Like the frontend, it communicates with the **Backend for Frontend (BFF)** for optimized data handling.

To start these components:

1. Start the **Backend for Frontend**:
   ```bash
   cd v6y-apps/bff
   pnpm start:dev
   ```

2. Start the **Frontend Back Office**:
   ```bash
   cd v6y-apps/front-bo
   pnpm start:dev
   ```

**🔵 GraphQL Playground:**
Access the playground at `http://localhost:4001/v6y/graphql` for testing queries and mutations.

#### ⚙ Backend Only

The **BFB Main Analyzer** retrieves the list of configured applications from the **database**. Each application contains a **Git repository URL (GitHub/GitLab)** and a **production URL**.

1.  **Main Analyzer Workflow:**
    
    -   The **main analyzer** checks out the repository as a ZIP file.
        
    -   The ZIP file is extracted to:
        
        ```
        v6y-apps/code-analysis-workspace
        ```
        
    -   Once the **source code is checked out**, further analysis does not require the main analyzer.
        
    -   Alternatively, contributors can manually download and extract the ZIP file into `code-analysis-workspace` and directly start the **static analyzer**.
        
2.  **Starting Static Analysis:**
    
    -   The **main analyzer** triggers the **static analyzer** (if required by the application type).
        
    -   If a new analyzer needs to be attached, modify `ApplicationManager.buildApplicationFrontendByBranch`:
        
        ```js
        try {
            await fetch(staticAuditorApiPath as string, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ applicationId, workspaceFolder }),
            });
        } catch (error) {
            AppLogger.info(
                `[ApplicationManager - buildApplicationFrontendByBranch - staticAuditor] error:  ${error}`
            );
        }

        try {
            await fetch(yourNewStaticAuditorUrl as string, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ applicationId, workspaceFolder }),
            });
        } catch (error) {
            AppLogger.info(
                `[ApplicationManager - buildApplicationFrontendByBranch - staticAuditor] error:  ${error}`
            );
        }
        ```
        
    -   Each analyzer **must have its own try-catch** to avoid failures from blocking others.
        
3.  **Dynamic Analysis Requires the Main Analyzer:**
    
    -   Dynamic analyzers run on **production URLs** and require real-time data.
        
    -   To attach a new dynamic analyzer, update `buildDynamicReports`:
        
        ```js
        const buildDynamicReports = async ({ application }: BuildApplicationParams) => {
            AppLogger.info('[ApplicationManager - buildDynamicReports] application: ', application?._id);
        
            if (!application) {
                return false;
            }
        
            try {
                await fetch(dynamicAuditorApiPath as string, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ applicationId: application?._id, workspaceFolder: null }),
                });
            } catch (error) {
                AppLogger.info(
                    `[ApplicationManager - buildDynamicReports - dynamicAuditor] error:  ${error}`
                );
            }
        };
        ```

    -   Each analyzer **must have its own try-catch** to avoid failures from blocking others.
            
4.  **Automated Keyword and Evolution Management:**
    
    -   The system automatically updates [keywords](https://github.com/ekino/v6y/blob/main/v6y-apps/bfb-main-analyzer/src/managers/KeywordManager.ts#L15) and [evolutions](https://github.com/ekino/v6y/blob/main/v6y-apps/bfb-main-analyzer/src/managers/EvolutionManager.ts#L52) based on audit results.
        
    -   No manual changes are required to insert keywords or track evolutions.

        
5.  **Ensuring Each Analyzer Runs in Isolation:**
    
    -   Each analyzer should run inside a **worker process** to prevent blocking the main thread:
        
        ```js
        await forkWorker('./src/workers/LighthouseAnalysisWorker.ts', workerConfig);
        await forkWorker('./src/workers/CodeQualityAnalysisWorker.ts', workerConfig);
        await forkWorker('./src/workers/DependenciesAnalysisWorker.ts', workerConfig);
        ```       
---

## 🗄 **Initial Database Data**

The initial database data is critical for the application to function correctly as it provides the foundational data structures and default configurations required for core features. For example, it may include:

- **Default Roles and Permissions**: Ensuring proper access control mechanisms are in place.
- **Configuration Settings**: Predefined settings to bootstrap the application.
- **Demo or Sample Data**: Allows you to test and verify features during development.

#### Steps to Load Initial Data:

1. Import the [tar file](https://github.com/ekino/v6y/blob/main/v6y-database/v6y_database) into your PostgreSQL database.

2. To use the Front, Front-BO, or query the BFF, create a **superadmin account** in the database. Use the following SQL command to insert the account:

   ```sql
   INSERT INTO accounts (username, email, password, role, created_at, updated_at, applications)
   VALUES (
     'superadmin', 
     'superadmin@example.com', 
     '$2a$10$fSDUAlp4s8gJNc7HtZdMdeevQHAyRgCy6knbL1QQz3pHstXSbWm0W', 
     'SUPERADMIN', 
     NOW(), 
     NOW(), 
     ARRAY[]::integer[]
   );
   ```

3. Include a Bearer token in the `Authorization` header for every query sent to the BFF. Obtain this token using the login query.

---

## 👥 **Contribution Guide**

1.  Check [GitHub Issues](https://github.com/ekino/v6y/issues) for `good first issue` or `help wanted` tags.
    
2.  Follow the [Contribution Guide](https://github.com/ekino/v6y/wiki/Contribution-Guide).

---

## 📜 **License**

This project is licensed under the MIT License. See the [LICENSE](https://github.com/ekino/v6y/blob/main/LICENSE) file for details.

---

## 📩 **Contact**

For further assistance, contact our support team or open an issue on GitHub.
