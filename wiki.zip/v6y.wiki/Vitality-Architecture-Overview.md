**Vitality** is a modular system designed for **scalability, maintainability, and seamless code auditing**. It ensures a **single source of truth** for all code quality, performance, and security assessments.

## 🧠 Architecture Diagram

![Architecture Diagram](https://github.com/user-attachments/assets/d6376ca3-e4e2-457e-a545-fb32dc42a1b7)

## 📂 Directory Structure

```
v6y-apps
├── front                # Main user interface (IHM)
├── front-bo             # Back-office interface (BO)
├── bff                  # Backend for Frontend (GraphQL, Node.js)
├── bfb-main-analyzer    # Central code analysis orchestrator
├── bfb-static-auditor   # Static code analysis module
├── bfb-devops-auditor   # DevOps metrics analyzer
├── bfb-url-dynamic-auditor # URL-based dynamic analysis (e.g., Lighthouse)

v6y-libs
├── core-logic           # Reusable backend logic
└── ui-kit               # Common UI components and hooks

ui-guide                 # Storybook documentation for ui-kit

persistence              # Database layer (PostgreSQL)
```

## 🧮 Component Descriptions

### **📌 Frontend (IHM)**

-   **Purpose:** User-facing interface for audit visualization, project tracking, and reporting.
-   **Technologies:** React, Next.js, GraphQL
-   **Guidelines:**
    -   Use **only** components from **ui-kit**.
    -   **No direct usage of UI libraries**—contribute missing components to **ui-kit**.
    -   All new components **must include tests and Storybook documentation (ui-guide)**.

### **📌 Frontend (BO)**

-   **Purpose:** Admin and configuration interface for managing applications and audit settings.
-   **Technologies:** React, Next.js, Refine, GraphQL
-   **UI Framework:** **Ant Design** (through **ui-kit**).

### **📌 Backend for Frontend (BFF)**

-   **Role:** Orchestrates frontend-backend communication via GraphQL.
-   **Technologies:** Node.js, GraphQL
-   **Responsibilities:**
    -   Data aggregation and transformation.
    -   Authentication and authorization.
    -   Rate limiting and caching.

### **📌 BFB Main Analyzer**

-   **Role:** **Single source of truth**—orchestrates auditing processes.
-   **Functionality:**
    -   Fetches applications configured in **BO**.
    -   Manages scheduled execution (every **midnight**).
    -   Determines which **BFB Auditors** to trigger.

### **📌 BFB Auditors**

-   **Purpose:** Specialized analysis modules using various tools.
-   **Existing Auditors:**
    -   **bfb-static-code-auditor:**
        -   Code complexity, duplication, modularity.
        -   Security vulnerabilities, dependency analysis.
    -   **bfb-devops-auditor:**
        -   DevOps **DORA metrics**, CI/CD health.
    -   **bfb-url-dynamic-auditor:**
        -   **Lighthouse audits** (Performance, SEO, Accessibility).

### **📌 Persistence Layer**

-   **Database:** PostgreSQL
-   **Responsibilities:**
    -   Stores **audit results and historical data**.
    -   Ensures **data consistency and integrity**.

## 🚦 Auditing Workflow

```
Scheduled Scan (Triggered at Midnight)
│
└──▶ BFB Main Analyzer (Scheduler)
    │
    ├── Fetches Applications List (from BO Configuration)
    │   ├── Each application is linked to:
    │   │   ├── Git Repository (GitHub/GitLab)
    │   │   └── Production URL
    │
    ├── Ensures Single Source of Truth:
    │   ├── Avoids multiple redundant checks on the same source code
    │   ├── Centralized orchestration of auditing tasks
    │
    ├── Triggers BFB Auditors (Child Analyzers)
    │   ├── Verifies if each child auditor is available before execution
    │   ├── Dispatches application analysis tasks
    │
    ├── Child Auditors Execution
    │   ├── Static Code Analysis:
    │   │   ├── Linting & Style Checks
    │   │   ├── Code Quality & Security
    │   │   ├── Dependencies Vulnerability Analysis
    │   │
    │   ├── Dynamic Analysis:
    │   │   ├── Lighthouse → Performance, SEO, Accessibility
    │   │   ├── API Security Audit → OWASP Compliance
    │   │
    │   ├── DevOps Metrics:
    │   │   ├── DORA Metrics → Deployment Frequency, Lead Time, etc.
    │   │   ├── CI/CD Pipeline Health Monitoring
    │
    ├── Reporting & Data Persistence
    │   ├── Aggregates results from all auditors
    │   ├── Generates structured reports
    │   ├── Stores analysis data in PostgreSQL (Historical Tracking)
    │
    └──▶ Frontend Display (IHM & BO)
        │
        ├── IHM (Developer Insights)
        │   ├── Displays audit results per application
        │   ├── Provides interactive filtering & search
        │   ├── Allows issue tracking & resolution workflows
        │
        ├── BO (Admin & Configuration)
        │   ├── Manages applications & linked repositories
        │   ├── Configures audit rules & thresholds
        │   ├── Monitors scheduled execution & overall system health
        │
        └──▶ Users can view reports, export data, and track historical trends 
```

## 🎨 Theming Guidelines

### **Adding a New Theme**
- Modify **[ThemeLoader.ts](https://github.com/ekino/v6y/blob/main/v6y-libs/ui-kit/src/theme/commons/ThemeLoader.ts)**.
- Add the necessary **[variants](https://github.com/ekino/v6y/tree/main/v6y-libs/ui-kit/src/theme/variants)** (e.g., admin, app).
- All theme-specific changes should reside within **ui-kit** and **ui-guide**.

## 📈 Reporting and Persistence

- **Reports Generation:** Summarizes findings, highlights critical issues, and suggests improvements.
- **Frontend Integration:**
  - **IHM** displays user-facing insights.
  - **BO** provides admin-level management and configuration tools.

## 🔍 Interaction with Repositories

- **Git Integration:** Supports both GitHub and GitLab repositories.
- **Process:**
  1. Monitors code changes.
  2. Automatically triggers analyses.
  3. Provides actionable feedback directly within the repository interface.

## ✅ Best Practices

### **Avoid Duplication**
- Shared logic goes to **core-logic (backend)** or **ui-kit (frontend)**.

### **Component Development**
- All UI components should be documented in **ui-guide** using **Storybook**.
- Contributions should follow the **design system principles** established in **ui-kit**.

### **Testing**
- Each module requires **unit and integration tests**.
- Use **Storybook** for **visual testing** of UI components.

---

Vitality is designed to provide scalable, efficient, and automated code auditing. By ensuring a clean, modular architecture, we maintain audit integrity, structured reporting, and developer-friendly visualization.

This system guarantees that code quality, security, and performance insights are accessible, actionable, and reliable. 🎯