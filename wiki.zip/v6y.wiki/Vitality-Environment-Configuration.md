This document outlines the necessary steps to configure environment variables for the Vitality project. Proper configuration ensures smooth local development, testing, and production deployment.

---

## **1. Local `.env` Files**

Each service should have its local `.env` file to store sensitive environment variables. For example:

- `v6y/.env`
- `v6y-apps/bff/.env`
- `v6y-apps/front/.env`
- `v6y-apps/front-bo/.env`

Ensure you update these files with every new variable.

---

## **2. `env-template` Files**

Every directory must have an `env-template` file to document required environment variables:

- `v6y/env-template`
- `v6y-apps/bff/env-template`
- `v6y-apps/front/env-template`
- `v6y-apps/front-bo/env-template`

The template should include placeholder values and descriptions of each variable.

Example:

```plaintext
PSQL_DB_HOST=127.0.0.1  # Database Host
PSQL_DB_NAME=postgres   # Database Name
```

---

## **3. Frontend Configuration (`environment.d.ts`)**

For the `front` and `front-bo` applications, define variables in `environment.d.ts`:

- `v6y-apps/front/environment.d.ts`

Example:

```typescript
export interface Environment {
  NEXT_PUBLIC_V6Y_BFF_PATH: string;
  NEXTAUTH_URL: string;
}
```

Add every new variable here to ensure TypeScript support.

---

## **4. Configuration Files**

### `docker-publish.yml`
Add secrets under `env` or map them dynamically based on environments (e.g., dev/prod).

```yaml
      - name: Set Environment Variables
        id: set-env
        run: |
          if [[ "${{ github.event_name }}" == "release" ]]; then
            echo "ENV=prod" >> $GITHUB_ENV
            echo "PSQL_DB_HOST=${{ secrets.PROD_PSQL_DB_HOST }}" >> $GITHUB_ENV
            echo "PSQL_DB_NAME=${{ secrets.PROD_PSQL_DB_NAME }}" >> $GITHUB_ENV
            ...
          else
            echo "ENV=dev" >> $GITHUB_ENV
            echo "PSQL_DB_HOST=${{ secrets.DEV_PSQL_DB_HOST }}" >> $GITHUB_ENV
            echo "PSQL_DB_NAME=${{ secrets.DEV_PSQL_DB_NAME }}" >> $GITHUB_ENV
            echo "PSQL_DB_USER=${{ secrets.DEV_PSQL_DB_USER }}" >> $GITHUB_ENV
            ...
```

### `node.js.yml`
Define variables for the Node.js CI workflow. Example snippet:

```yaml
      - name: Set Environment Variables
        id: set-env
        run: |
          if [[ "${{ github.event_name }}" == "release" ]]; then
            echo "ENV=prod" >> $GITHUB_ENV
            echo "PSQL_DB_HOST=${{ secrets.PROD_PSQL_DB_HOST }}" >> $GITHUB_ENV
            echo "PSQL_DB_NAME=${{ secrets.PROD_PSQL_DB_NAME }}" >> $GITHUB_ENV
            ...
          else
            echo "ENV=dev" >> $GITHUB_ENV
            echo "PSQL_DB_HOST=${{ secrets.DEV_PSQL_DB_HOST }}" >> $GITHUB_ENV
            echo "PSQL_DB_NAME=${{ secrets.DEV_PSQL_DB_NAME }}" >> $GITHUB_ENV
            ...
```

### `docker-compose.yml`
Ensure the `environment` section of each service is updated with required variables:

```yaml
    image: ghcr.io/<registry-owner>/xxx:latest
    environment:
      - PSQL_DB_HOST=${PSQL_DB_HOST}
      - PSQL_DB_NAME=${PSQL_DB_NAME}
      - PSQL_DB_USER=${PSQL_DB_USER}
```

---

## **5. GitHub Environments**

Update environment secrets in GitHub for `dev` and `prod`:

- Navigate to **Settings > Environments**.
- Add secrets for each variable.

Example:

- `DEV_PSQL_DB_HOST=127.0.0.1`
- `PROD_PSQL_DB_HOST=db.prod.example.com`

---

## **Checklist for Adding a New Variable**

1. Add to all local `.env` files.
2. Add to `env-template` files in relevant directories.
3. Update `environment.d.ts` for `front` and `front-bo`.
4. Add to configuration files (`docker-publish.yml`, `node.js.yml`, `docker-compose.yml`).
5. Add secrets to GitHub environments (`dev` and `prod`).

---

## **References**

- [`docker-publish.yml`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/.github/workflows/docker-publish.yml)
- [`node.js.yml`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/.github/workflows/node.js.yml)
- [`docker-compose.base.yml`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/docker-compose.base.yml)
- [`docker-compose.yml`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/docker-compose.yml)
- [`env-template`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/env-template)
- [`bff/env-template`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/v6y-apps/bff/env-template)
- [`environment.d.ts`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/v6y-apps/front/environment.d.ts)

---

Follow this guide to ensure proper management of environment variables across the Vitality project.
