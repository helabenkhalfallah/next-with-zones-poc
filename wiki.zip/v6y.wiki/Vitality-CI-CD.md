This page provides a detailed explanation of the CI/CD pipeline for the Vitality project. It describes the processes for building, testing, and deploying the application using GitHub Actions, Docker Compose, Docker Hub, and internal Ekino infrastructure.

---

## CI/CD Components

### 1. GitHub Actions for Build and Check

GitHub Actions is used to automate the CI pipeline, which includes building and testing the codebase.

#### Workflow File: `node.js.yml`

- **Location:** [`.github/workflows/node.js.yml`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/.github/workflows/node.js.yml)
- **Purpose:**
  - Runs checks for code quality and style.
  - Executes unit tests to ensure code stability.
  - Validates pull requests and commits before merging.

**Key Steps in the Workflow:**

1. **Install Dependencies:**
   Installs Node.js dependencies using `pnpm` for all modules in the monorepo.
2. **Run Linting:**
   Verifies code quality using ESLint.
3. **Run Tests:**
   Executes unit tests using the appropriate test runner.
4. **Build Artifacts:**
   Generates build artifacts for the frontend and backend components.

---

### 2. Docker Compose for Local and Production Environments

Docker Compose manages the containerized deployment of Vitality in both local and production environments.

#### Docker Compose Files:

1. **Base Configuration:**
   - **File:** [`docker-compose.base.yml`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/docker-compose.base.yml)
   - **Purpose:** Defines the base configuration shared between local and production setups, including service dependencies, networks, and environment variables.

2. **Main Configuration:**
   - **File:** [`docker-compose.yml`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/docker-compose.yml)
   - **Purpose:** Extends the base configuration with specific settings for each environment.

**Key Services Defined:**

- **Frontend:** React-based frontend application.
- **Backend:** Node.js and GraphQL-based backend for data processing.
- **Database:** PostgreSQL for persistence.
- **Auditors:** Specialized services for static and dynamic code analysis.

---

### 3. Docker Hub Integration

The pipeline publishes Docker images to Docker Hub for consistent and reusable deployments.

#### Workflow File: `docker-publish.yml`

- **Location:** [`.github/workflows/docker-publish.yml`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/.github/workflows/docker-publish.yml)
- **Purpose:** Automates the building and publishing of Docker images to Docker Hub.

**Key Steps in the Workflow:**

1. **Build Docker Images:**
   - Builds images using the [`Dockerfile`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/v6y-config/Dockerfile).
2. **Tag Images:**
   - Tags the images with the Git commit SHA and `latest` for versioning.
3. **Push to Docker Hub:**
   - Publishes the images to the Docker Hub repository.

---

### 4. GitHub Webhook for Internal Deployment

Vitality uses GitHub webhooks to trigger deployments on Ekino's internal infrastructure. This ensures secure and automated updates.

#### Workflow:

1. **Trigger:**
   - GitHub webhook sends a notification to the internal Ekino infrastructure upon successful builds.
2. **Internal Script Execution:**
   - The infrastructure pulls the latest Docker image from Docker Hub.
   - Updates the running containers using the latest image.
3. **Security Measures:**
   - Webhooks are configured with a secret token for validation.
   - Access is restricted to internal Ekino systems.

---

## Docker Images and Release Process

- **Development Version:**
  - When pushing to the `main` branch, a development Docker image is created. Example images:
    - [Frontend Dev Image](https://github.com/ekino/v6y/pkgs/container/v6y-frontend/336314440?tag=655f845e4a3ad4309bb783809b8e23bb8cc5e069)
    - [BFB Main Analyzer Dev Image](https://github.com/ekino/v6y/pkgs/container/v6y-bfb-main-analyzer/336314545?tag=655f845e4a3ad4309bb783809b8e23bb8cc5e069)

- **Production Version:**
  - When creating a release, a production Docker image is generated. Example images:
    - [Frontend Prod Image](https://github.com/ekino/v6y/pkgs/container/v6y-frontend/332340466?tag=1.0.0)
    - [BFB Main Analyzer Prod Image](https://github.com/ekino/v6y/pkgs/container/v6y-bfb-main-analyzer/332340497?tag=1.0.0)
  - Example release: [Release 1.0.0](https://github.com/ekino/v6y/releases/tag/1.0.0)

- **All Docker Images:**
  - Available at: [Ekino Packages](https://github.com/orgs/ekino/packages?repo_name=v6y)

---

## Additional Configuration

### Dockerfile

- **File:** [`Dockerfile`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/v6y-config/Dockerfile)
- **Purpose:** Defines the build process for containerizing Vitality components.

**Key Features:**

- Multi-stage builds to optimize image size.
- Caching of dependencies for faster builds.

### `.dockerignore`

- **File:** [`.dockerignore`](https://raw.githubusercontent.com/ekino/v6y/refs/heads/main/.dockerignore)
- **Purpose:** Excludes unnecessary files and directories from the Docker build context.
