const ApplicationDeleteOutput = `
  type ApplicationDeleteOutput {
      """ Application id """
      _id: Int!
  }
`;

export default ApplicationDeleteOutput;
