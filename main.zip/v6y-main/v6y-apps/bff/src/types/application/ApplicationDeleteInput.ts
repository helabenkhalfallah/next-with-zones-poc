const ApplicationDeleteInput = `
  input ApplicationDeleteInput {
      """ Application to delete id """
      id: String!
  }
`;

export default ApplicationDeleteInput;
