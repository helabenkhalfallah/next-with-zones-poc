const AccountCreateOrEditOutput = `
    type AccountCreateOrEditOutput {
        _id : Int
        token : String
    }
`;

export default AccountCreateOrEditOutput;
