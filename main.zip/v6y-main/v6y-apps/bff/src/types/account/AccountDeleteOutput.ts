const AccountDeleteOutput = `
  type AccountDeleteOutput {
      """ Account id """
      _id: Int!
  }
`;

export default AccountDeleteOutput;
