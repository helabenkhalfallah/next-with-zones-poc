const AccountUpdatePasswordOutput = `
    type AccountUpdatePasswordOutput {
        """ Account id """
        _id: Int!
    }
`;

export default AccountUpdatePasswordOutput;
