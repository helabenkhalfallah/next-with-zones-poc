const AccountLoginInput = `
    input AccountLoginInput {
        """ Account Email """
        email: String!
        
        """ Account Password """
        password: String!
    }
`;

export default AccountLoginInput;
