const AccountDeleteInput = `
    input AccountDeleteInput {
       """ Account to delete id """
       id: String!
    }
`;

export default AccountDeleteInput;
