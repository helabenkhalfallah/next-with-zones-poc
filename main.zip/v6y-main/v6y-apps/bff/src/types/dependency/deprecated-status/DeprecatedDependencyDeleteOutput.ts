const DeprecatedDependencyDeleteOutput = `
  type DeprecatedDependencyDeleteOutput {
      """ Deprecated Dependency id """
      _id: Int!
  }
`;

export default DeprecatedDependencyDeleteOutput;
