const DeprecatedDependencyCreateOrEditInput = `
  input DeprecatedDependencyCreateOrEditInput {
    """ Deprecated Dependency Unique id """
    _id: Int
      
    """ Deprecated Dependency Name """
    name: String!
  }
`;

export default DeprecatedDependencyCreateOrEditInput;
