const DeprecatedDependencyDeleteInput = `
  input DeprecatedDependencyDeleteInput {
      """ Deprecated Dependency to delete id """
      id: String!
  }
`;

export default DeprecatedDependencyDeleteInput;
