const DependencyStatusHelpDeleteOutput = `
  type DependencyStatusHelpDeleteOutput {
      """ DependencyStatus Help id """
      _id: Int!
  }
`;

export default DependencyStatusHelpDeleteOutput;
