const DependencyStatusHelpDeleteInput = `
  input DependencyStatusHelpDeleteInput {
      """ DependencyStatus Help to delete id """
      id: String!
  }
`;

export default DependencyStatusHelpDeleteInput;
