const AuditHelpDeleteInput = `
  input AuditHelpDeleteInput {
      """ Audit Help to delete id """
      id: String!
  }
`;

export default AuditHelpDeleteInput;
