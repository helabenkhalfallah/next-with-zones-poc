const AuditHelpDeleteOutput = `
  type AuditHelpDeleteOutput {
      """ Audit Help id """
      _id: Int!
  }
`;

export default AuditHelpDeleteOutput;
