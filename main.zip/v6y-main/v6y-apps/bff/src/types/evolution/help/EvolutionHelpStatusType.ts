const EvolutionHelpStatusType = `
  type EvolutionHelpStatusType {
    """ Evolution Help Status Label """
    label: String!
    
    """ Evolution Help Status Value """
    value: String!
  }
`;

export default EvolutionHelpStatusType;
