const EvolutionHelpDeleteInput = `
  input EvolutionHelpDeleteInput {
      """ Evolution Help to delete id """
      id: String!
  }
`;

export default EvolutionHelpDeleteInput;
