const EvolutionHelpDeleteOutput = `
  type EvolutionHelpDeleteOutput {
      """ Evolution Help id """
      _id: Int!
  }
`;

export default EvolutionHelpDeleteOutput;
