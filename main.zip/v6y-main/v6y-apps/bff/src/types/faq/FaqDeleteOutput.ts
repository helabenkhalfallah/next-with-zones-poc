const FaqDeleteOutput = `
  type FaqDeleteOutput {
      """ Faq id """
      _id: Int!
  }
`;

export default FaqDeleteOutput;
