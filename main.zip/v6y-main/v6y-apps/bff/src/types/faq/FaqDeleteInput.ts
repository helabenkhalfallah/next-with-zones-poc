const FaqDeleteInput = `
  input FaqDeleteInput {
      """ Faq to delete id """
      id: String!
  }
`;

export default FaqDeleteInput;
