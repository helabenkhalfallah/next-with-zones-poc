const NotificationDeleteInput = `
  input NotificationDeleteInput {
      """ Notification to delete id """
      id: String!
  }
`;

export default NotificationDeleteInput;
