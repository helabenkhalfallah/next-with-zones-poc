const NotificationDeleteOutput = `
  type NotificationDeleteOutput {
      """ Notification id """
      _id: Int!
  }
`;

export default NotificationDeleteOutput;
