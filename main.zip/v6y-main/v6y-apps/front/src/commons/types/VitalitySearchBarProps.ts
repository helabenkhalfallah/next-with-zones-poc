export interface VitalitySearchBarProps {
    helper: string;
    label: string;
    status?: '' | 'warning' | 'error' | undefined;
    placeholder: string;
}
