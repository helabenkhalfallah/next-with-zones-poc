const VitalityPageFooter = () => <>Footer</>;

export default VitalityPageFooter;
