const VitalityNavigationPaths = {
    DASHBOARD: '/dashboard',
    APP_LIST: '/app-list',
    APP_DETAILS: '/app-details',
    FAQ: '/faq',
    NOTIFICATIONS: '/notifications',
    APPS_STATS: '/apps-stats',
    SEARCH: '/search',
    LOGIN: '/login',
};

export default VitalityNavigationPaths;
