import VitalityAppListView from '../components/VitalityAppListView';

export default function VitalityAppListPage() {
    return <VitalityAppListView />;
}
