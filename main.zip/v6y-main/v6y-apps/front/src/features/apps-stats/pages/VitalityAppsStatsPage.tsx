import VitalityAppsStatsView from '../components/VitalityAppsStatsView';

export default function VitalityAppsStatsPage() {
    return <VitalityAppsStatsView />;
}
