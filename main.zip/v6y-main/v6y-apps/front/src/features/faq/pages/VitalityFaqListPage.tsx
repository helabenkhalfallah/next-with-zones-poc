import VitalityFaqView from '../components/VitalityFaqView';

export default function VitalityFaqListPage() {
    return <VitalityFaqView />;
}
