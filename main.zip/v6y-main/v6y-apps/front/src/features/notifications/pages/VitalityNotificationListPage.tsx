import VitalityNotificationView from '../components/VitalityNotificationView';

export default function VitalityNotificationListPage() {
    return <VitalityNotificationView />;
}
