import VitalityDashboardView from '../components/VitalityDashboardView';

export default function VitalityDashboardPage() {
    return <VitalityDashboardView />;
}
