import VitalityAppDetailsView from '../components/VitalityAppDetailsView';

export default function VitalityAppDetailsPage() {
    return <VitalityAppDetailsView />;
}
