import VitalitySearchView from '../components/VitalitySearchView';

export default function VitalitySearchPage() {
    return <VitalitySearchView />;
}
