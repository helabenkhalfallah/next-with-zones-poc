import VitalityDashboardPage from '../../features/dashboard/pages/VitalityDashboardPage';

export default VitalityDashboardPage;
