import VitalityAppListPage from '../../features/app-list/pages/VitalityAppListPage';

export default VitalityAppListPage;
