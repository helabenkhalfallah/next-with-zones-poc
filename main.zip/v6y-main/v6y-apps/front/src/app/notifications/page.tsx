import VitalityNotificationListPage from '../../features/notifications/pages/VitalityNotificationListPage';

export default VitalityNotificationListPage;
