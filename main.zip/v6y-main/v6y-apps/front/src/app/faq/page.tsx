import VitalityFaqListPage from '../../features/faq/pages/VitalityFaqListPage';

export default VitalityFaqListPage;
