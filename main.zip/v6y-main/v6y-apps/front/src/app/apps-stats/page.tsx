import VitalityAppsStatsPage from '../../features/apps-stats/pages/VitalityAppsStatsPage';

export default VitalityAppsStatsPage;
