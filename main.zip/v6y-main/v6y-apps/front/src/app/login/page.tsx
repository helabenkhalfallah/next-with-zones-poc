import VitalityLoginPage from '../../features/auth/pages/VitalityLoginPage';

export default VitalityLoginPage;
