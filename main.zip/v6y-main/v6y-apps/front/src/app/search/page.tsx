import VitalitySearchPage from '../../features/search/pages/VitalitySearchPage';

export default VitalitySearchPage;
