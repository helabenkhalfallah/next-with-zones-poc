import VitalityAppDetailsPage from '../../features/app-details/pages/VitalityAppDetailsPage';

export default VitalityAppDetailsPage;
