// Audit ranges (in day)
const AUDIT_RANGES = [30];

const DoraMetricsConfig = {
    AUDIT_RANGES,
};

export default DoraMetricsConfig;
