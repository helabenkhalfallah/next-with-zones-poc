import { ApplicationType } from '@v6y/core-logic';

export interface AuditCommonsType {
    applicationId?: number;
    application?: ApplicationType;
}
