import * as React from 'react';

const VitalityPageFooter = () => {
    return <div>Custom Footer Content</div>;
};

export default VitalityPageFooter;
