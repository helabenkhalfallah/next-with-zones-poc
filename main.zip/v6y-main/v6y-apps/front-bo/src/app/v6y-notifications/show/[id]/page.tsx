'use client';

import * as React from 'react';

import VitalityNotificationDetailsView from '../../../../features/v6y-notifications/components/VitalityNotificationDetailsView';

export default function VitalityNotificationDetailsPage() {
    return <VitalityNotificationDetailsView />;
}
