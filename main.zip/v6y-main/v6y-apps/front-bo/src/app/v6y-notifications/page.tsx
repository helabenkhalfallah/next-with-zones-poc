'use client';

import * as React from 'react';

import VitalityNotificationListView from '../../features/v6y-notifications/components/VitalityNotificationListView';

export default function NotificationList() {
    return <VitalityNotificationListView />;
}
