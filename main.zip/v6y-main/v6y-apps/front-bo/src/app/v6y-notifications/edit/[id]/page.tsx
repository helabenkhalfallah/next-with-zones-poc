'use client';

import * as React from 'react';

import VitalityNotificationEditView from '../../../../features/v6y-notifications/components/VitalityNotificationEditView';

export default function VitalityNotificationEditPage() {
    return <VitalityNotificationEditView />;
}
