'use client';

import * as React from 'react';

import VitalityNotificationCreateView from '../../../features/v6y-notifications/components/VitalityNotificationCreateView';

export default function VitalityNotificationCreatePage() {
    return <VitalityNotificationCreateView />;
}
