'use client';

import * as React from 'react';

import VitalityAccountListView from '../../features/v6y-accounts/components/VitalityAccountListView';

export default function AccountList() {
    return <VitalityAccountListView />;
}
