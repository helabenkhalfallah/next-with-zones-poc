'use client';

import * as React from 'react';

import VitalityAccountCreateView from '../../../features/v6y-accounts/components/VitalityAccountCreateView';

export default function VitalityAccountCreatePage() {
    return <VitalityAccountCreateView />;
}
