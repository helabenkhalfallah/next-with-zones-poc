'use client';

import * as React from 'react';

import VitalityAccountEditView from '../../../../features/v6y-accounts/components/VitalityAccountEditView';

export default function VitalityAccountEditPage() {
    return <VitalityAccountEditView />;
}
