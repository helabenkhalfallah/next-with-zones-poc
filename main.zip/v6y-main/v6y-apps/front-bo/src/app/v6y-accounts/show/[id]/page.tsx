'use client';

import * as React from 'react';

import VitalityAccountDetailsView from '../../../../features/v6y-accounts/components/VitalityAccountDetailsView';

export default function VitalityAccountDetailsPage() {
    return <VitalityAccountDetailsView />;
}
