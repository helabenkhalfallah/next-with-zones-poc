'use client';

import * as React from 'react';

import VitalityEvolutionHelpListView from '../../features/v6y-evolution-helps/components/VitalityEvolutionHelpListView';

export default function EvolutionList() {
    return <VitalityEvolutionHelpListView />;
}
