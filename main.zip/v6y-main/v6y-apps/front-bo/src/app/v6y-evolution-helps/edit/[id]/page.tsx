'use client';

import * as React from 'react';

import VitalityEvolutionHelpEditView from '../../../../features/v6y-evolution-helps/components/VitalityEvolutionHelpEditView';

export default function VitalityEvolutionEditPage() {
    return <VitalityEvolutionHelpEditView />;
}
