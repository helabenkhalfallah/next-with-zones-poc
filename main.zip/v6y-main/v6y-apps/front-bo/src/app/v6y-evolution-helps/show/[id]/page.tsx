'use client';

import * as React from 'react';

import VitalityEvolutionHelpDetailsView from '../../../../features/v6y-evolution-helps/components/VitalityEvolutionHelpDetailsView';

export default function VitalityEvolutionDetailsPage() {
    return <VitalityEvolutionHelpDetailsView />;
}
