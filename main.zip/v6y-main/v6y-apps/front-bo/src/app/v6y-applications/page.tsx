'use client';

import * as React from 'react';

import VitalityApplicationListView from '../../features/v6y-applications/components/VitalityApplicationListView';

export default function VitalityApplicationListPage() {
    return <VitalityApplicationListView />;
}
