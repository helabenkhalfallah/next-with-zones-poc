'use client';

import * as React from 'react';

import VitalityApplicationCreateView from '../../../features/v6y-applications/components/VitalityApplicationCreateView';

export default function VitalityApplicationCreatePage() {
    return <VitalityApplicationCreateView />;
}
