'use client';

import * as React from 'react';

import VitalityApplicationEditView from '../../../../features/v6y-applications/components/VitalityApplicationEditView';

export default function VitalityApplicationEditPage() {
    return <VitalityApplicationEditView />;
}
