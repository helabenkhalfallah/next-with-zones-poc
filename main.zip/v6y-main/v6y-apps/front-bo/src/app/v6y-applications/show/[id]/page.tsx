'use client';

import * as React from 'react';

import VitalityApplicationDetailsView from '../../../../features/v6y-applications/components/VitalityApplicationDetailsView';

export default function VitalityApplicationDetailsPage() {
    return <VitalityApplicationDetailsView />;
}
