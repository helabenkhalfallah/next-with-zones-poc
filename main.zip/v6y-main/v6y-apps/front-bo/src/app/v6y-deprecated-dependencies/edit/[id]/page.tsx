'use client';

import * as React from 'react';

import VitalityDeprecatedDependencyEditView from '../../../../features/v6y-deprecated-dependencies/components/VitalityDeprecatedDependencyEditView';

export default function VitalityDependencyEditPage() {
    return <VitalityDeprecatedDependencyEditView />;
}
