'use client';

import * as React from 'react';

import VitalityDeprecatedDependencyListView from '../../features/v6y-deprecated-dependencies/components/VitalityDeprecatedDependencyListView';

export default function DependencyList() {
    return <VitalityDeprecatedDependencyListView />;
}
