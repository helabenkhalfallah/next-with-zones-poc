'use client';

import * as React from 'react';

import VitalityDeprecatedDependencyDetailsView from '../../../../features/v6y-deprecated-dependencies/components/VitalityDeprecatedDependencyDetailsView';

export default function VitalityDependencyDetailsPage() {
    return <VitalityDeprecatedDependencyDetailsView />;
}
