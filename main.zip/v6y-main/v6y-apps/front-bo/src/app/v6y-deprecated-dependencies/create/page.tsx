'use client';

import * as React from 'react';

import VitalityDeprecatedDependencyCreateView from '../../../features/v6y-deprecated-dependencies/components/VitalityDeprecatedDependencyCreateView';

export default function VitalityDependencyCreatePage() {
    return <VitalityDeprecatedDependencyCreateView />;
}
