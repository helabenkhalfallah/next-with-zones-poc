'use client';

import * as React from 'react';

import VitalityDependencyStatusHelpEditView from '../../../../features/v6y-dependency-status-helps/components/VitalityDependencyStatusHelpEditView';

export default function VitalityDependencyEditPage() {
    return <VitalityDependencyStatusHelpEditView />;
}
