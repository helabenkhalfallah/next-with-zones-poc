'use client';

import * as React from 'react';

import VitalityDependencyStatusHelpDetailsView from '../../../../features/v6y-dependency-status-helps/components/VitalityDependencyStatusHelpDetailsView';

export default function VitalityDependencyDetailsPage() {
    return <VitalityDependencyStatusHelpDetailsView />;
}
