'use client';

import * as React from 'react';

import VitalityDependencyStatusHelpListView from '../../features/v6y-dependency-status-helps/components/VitalityDependencyStatusHelpListView';

export default function DependencyList() {
    return <VitalityDependencyStatusHelpListView />;
}
