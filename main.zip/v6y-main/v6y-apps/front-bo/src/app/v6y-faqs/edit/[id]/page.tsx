'use client';

import * as React from 'react';

import VitalityFaqEditView from '../../../../features/v6y-faqs/components/VitalityFaqEditView';

export default function VitalityFaqEditPage() {
    return <VitalityFaqEditView />;
}
