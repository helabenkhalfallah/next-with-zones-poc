'use client';

import * as React from 'react';

import VitalityFaqListView from '../../features/v6y-faqs/components/VitalityFaqListView';

export default function FaqList() {
    return <VitalityFaqListView />;
}
