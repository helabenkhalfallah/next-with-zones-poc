'use client';

import * as React from 'react';

import VitalityFaqCreateView from '../../../features/v6y-faqs/components/VitalityFaqCreateView';

export default function VitalityFaqCreatePage() {
    return <VitalityFaqCreateView />;
}
