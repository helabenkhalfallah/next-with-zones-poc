'use client';

import * as React from 'react';

import VitalityFaqDetailsView from '../../../../features/v6y-faqs/components/VitalityFaqDetailsView';

export default function VitalityFaqDetailsPage() {
    return <VitalityFaqDetailsView />;
}
