import * as React from 'react';

export default function Loading() {
    // Or a custom loading skeleton component
    return <p>Loading...</p>;
}
