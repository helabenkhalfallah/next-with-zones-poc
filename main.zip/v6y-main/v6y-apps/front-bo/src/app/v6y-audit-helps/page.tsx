'use client';

import * as React from 'react';

import VitalityAuditHelpListView from '../../features/v6y-audit-help/components/VitalityAuditHelpListView';

export default function AuditList() {
    return <VitalityAuditHelpListView />;
}
