'use client';

import * as React from 'react';

import VitalityAuditHelpDetailsView from '../../../../features/v6y-audit-help/components/VitalityAuditHelpDetailsView';

export default function VitalityAuditDetailsPage() {
    return <VitalityAuditHelpDetailsView />;
}
