'use client';

import * as React from 'react';

import VitalityAuditHelpEditView from '../../../../features/v6y-audit-help/components/VitalityAuditHelpEditView';

export default function VitalityAuditEditPage() {
    return <VitalityAuditHelpEditView />;
}
